module.exports = {

"[project]/app/lib/data:2b146f [app-ssr] (ecmascript) <text/javascript>": ((__turbopack_context__) => {
"use strict";

{
/* __next_internal_action_entry_do_not_use__ [{"6037d6e796b727171c060e55f262911d668dfeeb62":"authenticate"},"app/lib/actions.ts",""] */ __turbopack_context__.s({
    "authenticate": (()=>authenticate)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$0$2d$canary$2e$34_react_7c4e108657a2500366dd8081e08c8b03$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.0-canary.34_react_7c4e108657a2500366dd8081e08c8b03/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-ssr] (ecmascript)");
"use turbopack no side effects";
;
var authenticate = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$0$2d$canary$2e$34_react_7c4e108657a2500366dd8081e08c8b03$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createServerReference"])("6037d6e796b727171c060e55f262911d668dfeeb62", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$0$2d$canary$2e$34_react_7c4e108657a2500366dd8081e08c8b03$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$0$2d$canary$2e$34_react_7c4e108657a2500366dd8081e08c8b03$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["findSourceMapURL"], "authenticate"); //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vYWN0aW9ucy50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIndXNlIHNlcnZlcic7XHJcblxyXG5pbXBvcnQgeyB6IH0gZnJvbSAnem9kJztcclxuaW1wb3J0IHsgcmV2YWxpZGF0ZVBhdGggfSBmcm9tICduZXh0L2NhY2hlJztcclxuaW1wb3J0IHBvc3RncmVzIGZyb20gJ3Bvc3RncmVzJztcclxuaW1wb3J0IHsgcmVkaXJlY3QgfSBmcm9tICduZXh0L25hdmlnYXRpb24nO1xyXG5pbXBvcnQgeyBzaWduSW4gfSBmcm9tICdAL2F1dGgnO1xyXG5pbXBvcnQgeyBBdXRoRXJyb3IgfSBmcm9tICduZXh0LWF1dGgnO1xyXG5jb25zdCBzcWwgPSBwb3N0Z3Jlcyhwcm9jZXNzLmVudi5QT1NUR1JFU19VUkwhLCB7IHNzbDogJ3JlcXVpcmUnIH0pO1xyXG5cclxuLy8gRGVmaW5pciBlc3F1ZW1hIHBhcmEgbGEgdmFsaWRhY2nDs24gZGUgZm9ybXVsYXJpb3NcclxuY29uc3QgRm9ybVNjaGVtYSA9IHoub2JqZWN0KHtcclxuICBpZDogei5zdHJpbmcoKSxcclxuICBjdXN0b21lcklkOiB6LnN0cmluZyh7XHJcbiAgICBpbnZhbGlkX3R5cGVfZXJyb3I6ICdQbGVhc2Ugc2VsZWN0IGEgY3VzdG9tZXIuJyxcclxuICB9KSxcclxuICBhbW91bnQ6IHouY29lcmNlLm51bWJlcigpXHJcbiAgICAuZ3QoMCwgeyBtZXNzYWdlOiAnUGxlYXNlIGVudGVyIGFuIGFtb3VudCBncmVhdGVyIHRoYW4gJDAuJyB9KSxcclxuICBcclxuICBzdGF0dXM6IHouZW51bShbJ3BlbmRpbmcnLCAncGFpZCddLCB7XHJcbiAgICBpbnZhbGlkX3R5cGVfZXJyb3I6ICdQbGVhc2Ugc2VsZWN0IGFuIGludm9pY2Ugc3RhdHVzLicsXHJcbiAgfSksXHJcbiAgZGF0ZTogei5zdHJpbmcoKSxcclxufSk7XHJcblxyXG4vLyBDcmVhciB1biBlc3F1ZW1hIHBhcmEgbGEgY3JlYWNpw7NuIGRlIGZhY3R1cmFzIChvbWl0aW1vcyBpZCB5IGRhdGUpXHJcbmNvbnN0IENyZWF0ZUludm9pY2UgPSBGb3JtU2NoZW1hLm9taXQoeyBpZDogdHJ1ZSwgZGF0ZTogdHJ1ZSB9KTtcclxuZXhwb3J0IHR5cGUgU3RhdGUgPSB7XHJcbiAgZXJyb3JzPzoge1xyXG4gICAgY3VzdG9tZXJJZD86IHN0cmluZ1tdO1xyXG4gICAgYW1vdW50Pzogc3RyaW5nW107XHJcbiAgICBzdGF0dXM/OiBzdHJpbmdbXTtcclxuICB9O1xyXG4gIG1lc3NhZ2U/OiBzdHJpbmcgfCBudWxsO1xyXG59O1xyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNyZWF0ZUludm9pY2UocHJldlN0YXRlOiBTdGF0ZSwgZm9ybURhdGE6IEZvcm1EYXRhKSB7XHJcbiAgLy8gVmFsaWRhdGUgZm9ybSB1c2luZyBab2RcclxuICBjb25zdCB2YWxpZGF0ZWRGaWVsZHMgPSBDcmVhdGVJbnZvaWNlLnNhZmVQYXJzZSh7XHJcbiAgICBjdXN0b21lcklkOiBmb3JtRGF0YS5nZXQoJ2N1c3RvbWVySWQnKSxcclxuICAgIGFtb3VudDogZm9ybURhdGEuZ2V0KCdhbW91bnQnKSxcclxuICAgIHN0YXR1czogZm9ybURhdGEuZ2V0KCdzdGF0dXMnKSxcclxuICB9KTtcclxuIFxyXG4gIC8vIElmIGZvcm0gdmFsaWRhdGlvbiBmYWlscywgcmV0dXJuIGVycm9ycyBlYXJseS4gT3RoZXJ3aXNlLCBjb250aW51ZS5cclxuICBpZiAoIXZhbGlkYXRlZEZpZWxkcy5zdWNjZXNzKSB7XHJcbiAgICByZXR1cm4ge1xyXG4gICAgICBlcnJvcnM6IHZhbGlkYXRlZEZpZWxkcy5lcnJvci5mbGF0dGVuKCkuZmllbGRFcnJvcnMsXHJcbiAgICAgIG1lc3NhZ2U6ICdNaXNzaW5nIEZpZWxkcy4gRmFpbGVkIHRvIENyZWF0ZSBJbnZvaWNlLicsXHJcbiAgICB9O1xyXG4gIH1cclxuIFxyXG4gIC8vIFByZXBhcmUgZGF0YSBmb3IgaW5zZXJ0aW9uIGludG8gdGhlIGRhdGFiYXNlXHJcbiAgY29uc3QgeyBjdXN0b21lcklkLCBhbW91bnQsIHN0YXR1cyB9ID0gdmFsaWRhdGVkRmllbGRzLmRhdGE7XHJcbiAgY29uc3QgYW1vdW50SW5DZW50cyA9IGFtb3VudCAqIDEwMDtcclxuICBjb25zdCBkYXRlID0gbmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNwbGl0KCdUJylbMF07XHJcbiBcclxuICAvLyBJbnNlcnQgZGF0YSBpbnRvIHRoZSBkYXRhYmFzZVxyXG4gIHRyeSB7XHJcbiAgICBhd2FpdCBzcWxgXHJcbiAgICAgIElOU0VSVCBJTlRPIGludm9pY2VzIChjdXN0b21lcl9pZCwgYW1vdW50LCBzdGF0dXMsIGRhdGUpXHJcbiAgICAgIFZBTFVFUyAoJHtjdXN0b21lcklkfSwgJHthbW91bnRJbkNlbnRzfSwgJHtzdGF0dXN9LCAke2RhdGV9KVxyXG4gICAgYDtcclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgLy8gSWYgYSBkYXRhYmFzZSBlcnJvciBvY2N1cnMsIHJldHVybiBhIG1vcmUgc3BlY2lmaWMgZXJyb3IuXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICBtZXNzYWdlOiAnRGF0YWJhc2UgRXJyb3I6IEZhaWxlZCB0byBDcmVhdGUgSW52b2ljZS4nLFxyXG4gICAgfTtcclxuICB9XHJcbiBcclxuICAvLyBSZXZhbGlkYXRlIHRoZSBjYWNoZSBmb3IgdGhlIGludm9pY2VzIHBhZ2UgYW5kIHJlZGlyZWN0IHRoZSB1c2VyLlxyXG4gIHJldmFsaWRhdGVQYXRoKCcvZGFzaGJvYXJkL2ludm9pY2VzJyk7XHJcbiAgcmVkaXJlY3QoJy9kYXNoYm9hcmQvaW52b2ljZXMnKTtcclxufVxyXG5cclxuY29uc3QgVXBkYXRlSW52b2ljZSA9IEZvcm1TY2hlbWEub21pdCh7IGlkOiB0cnVlLCBkYXRlOiB0cnVlIH0pO1xyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZUludm9pY2UoaWQ6IHN0cmluZywgZm9ybURhdGE6IEZvcm1EYXRhKSB7XHJcbiAgY29uc3QgeyBjdXN0b21lcklkLCBhbW91bnQsIHN0YXR1cyB9ID0gVXBkYXRlSW52b2ljZS5wYXJzZSh7XHJcbiAgICBjdXN0b21lcklkOiBmb3JtRGF0YS5nZXQoJ2N1c3RvbWVySWQnKSxcclxuICAgIGFtb3VudDogZm9ybURhdGEuZ2V0KCdhbW91bnQnKSxcclxuICAgIHN0YXR1czogZm9ybURhdGEuZ2V0KCdzdGF0dXMnKSxcclxuICB9KTtcclxuIFxyXG4gIGNvbnN0IGFtb3VudEluQ2VudHMgPSBhbW91bnQgKiAxMDA7XHJcbiBcclxuICB0cnkge1xyXG4gICAgYXdhaXQgc3FsYFxyXG4gICAgICAgIFVQREFURSBpbnZvaWNlc1xyXG4gICAgICAgIFNFVCBjdXN0b21lcl9pZCA9ICR7Y3VzdG9tZXJJZH0sIGFtb3VudCA9ICR7YW1vdW50SW5DZW50c30sIHN0YXR1cyA9ICR7c3RhdHVzfVxyXG4gICAgICAgIFdIRVJFIGlkID0gJHtpZH1cclxuICAgICAgYDtcclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgXHJcbiAgICBjb25zb2xlLmVycm9yKGVycm9yKTtcclxuICB9XHJcbiBcclxuICByZXZhbGlkYXRlUGF0aCgnL2Rhc2hib2FyZC9pbnZvaWNlcycpO1xyXG4gIHJlZGlyZWN0KCcvZGFzaGJvYXJkL2ludm9pY2VzJyk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkZWxldGVJbnZvaWNlKGlkOiBzdHJpbmcpIHtcclxuICB0cnkge1xyXG4gICAgLy8gRWxpbWluYWNpw7NuIGRlIGxhIGZhY3R1cmEgZW4gbGEgYmFzZSBkZSBkYXRvc1xyXG4gICAgYXdhaXQgc3FsYERFTEVURSBGUk9NIGludm9pY2VzIFdIRVJFIGlkID0gJHtpZH1gO1xyXG4gICAgXHJcbiAgICAvLyBSZWRpcmVjY2nDs24geSByZXZhbGlkYWNpw7NuIGRlc3B1w6lzIGRlIGxhIGVsaW1pbmFjacOzblxyXG4gICAgcmV2YWxpZGF0ZVBhdGgoJy9kYXNoYm9hcmQvaW52b2ljZXMnKTtcclxuICAgIHJlZGlyZWN0KCcvZGFzaGJvYXJkL2ludm9pY2VzJyk7XHJcbiAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoJ0Vycm9yIGFsIGVsaW1pbmFyIGxhIGZhY3R1cmE6JywgZXJyb3IpO1xyXG4gICAgLy8gdGhyb3cgbmV3IEVycm9yKCdIdWJvIHVuIHByb2JsZW1hIGFsIGVsaW1pbmFyIGxhIGZhY3R1cmEuJyk7XHJcbiAgfVxyXG59XHJcblxyXG5cclxuIFxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gYXV0aGVudGljYXRlKFxyXG4gIHByZXZTdGF0ZTogc3RyaW5nIHwgdW5kZWZpbmVkLFxyXG4gIGZvcm1EYXRhOiBGb3JtRGF0YSxcclxuKSB7XHJcbiAgdHJ5IHtcclxuICAgIGF3YWl0IHNpZ25JbignY3JlZGVudGlhbHMnLCBmb3JtRGF0YSk7XHJcbiAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIGlmIChlcnJvciBpbnN0YW5jZW9mIEF1dGhFcnJvcikge1xyXG4gICAgICBzd2l0Y2ggKGVycm9yLnR5cGUpIHtcclxuICAgICAgICBjYXNlICdDcmVkZW50aWFsc1NpZ25pbic6XHJcbiAgICAgICAgICByZXR1cm4gJ0ludmFsaWQgY3JlZGVudGlhbHMuJztcclxuICAgICAgICBkZWZhdWx0OlxyXG4gICAgICAgICAgcmV0dXJuICdTb21ldGhpbmcgd2VudCB3cm9uZy4nO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICB0aHJvdyBlcnJvcjtcclxuICB9XHJcbn1cclxuXHJcblxyXG4vLyAndXNlIHNlcnZlcic7XHJcblxyXG4vLyBpbXBvcnQgeyB6IH0gZnJvbSAnem9kJztcclxuLy8gaW1wb3J0IHsgcmV2YWxpZGF0ZVBhdGggfSBmcm9tICduZXh0L2NhY2hlJztcclxuLy8gaW1wb3J0IHBvc3RncmVzIGZyb20gJ3Bvc3RncmVzJztcclxuLy8gaW1wb3J0IHsgcmVkaXJlY3QgfSBmcm9tICduZXh0L25hdmlnYXRpb24nO1xyXG4vLyBjb25zdCBzcWwgPSBwb3N0Z3Jlcyhwcm9jZXNzLmVudi5QT1NUR1JFU19VUkwhLCB7IHNzbDogJ3JlcXVpcmUnIH0pO1xyXG4gXHJcbi8vIGNvbnN0IEZvcm1TY2hlbWEgPSB6Lm9iamVjdCh7XHJcbi8vICAgaWQ6IHouc3RyaW5nKCksXHJcbi8vICAgY3VzdG9tZXJJZDogei5zdHJpbmcoKSxcclxuLy8gICBhbW91bnQ6IHouY29lcmNlLm51bWJlcigpLFxyXG4vLyAgIHN0YXR1czogei5lbnVtKFsncGVuZGluZycsICdwYWlkJ10pLFxyXG4vLyAgIGRhdGU6IHouc3RyaW5nKCksXHJcbi8vIH0pO1xyXG4gXHJcbi8vIGNvbnN0IENyZWF0ZUludm9pY2UgPSBGb3JtU2NoZW1hLm9taXQoeyBpZDogdHJ1ZSwgZGF0ZTogdHJ1ZSB9KTtcclxuXHJcblxyXG4vLyBleHBvcnQgYXN5bmMgZnVuY3Rpb24gY3JlYXRlSW52b2ljZShmb3JtRGF0YTogRm9ybURhdGEpIHtcclxuICAgXHJcbiAgICBcclxuLy8gICBjb25zdCB7IGN1c3RvbWVySWQsIGFtb3VudCwgc3RhdHVzIH0gPSBDcmVhdGVJbnZvaWNlLnBhcnNlKHtcclxuLy8gICAgIGN1c3RvbWVySWQ6IGZvcm1EYXRhLmdldCgnY3VzdG9tZXJJZCcpLFxyXG4vLyAgICAgYW1vdW50OiBmb3JtRGF0YS5nZXQoJ2Ftb3VudCcpLFxyXG4vLyAgICAgc3RhdHVzOiBmb3JtRGF0YS5nZXQoJ3N0YXR1cycpLFxyXG4vLyAgIH0pO1xyXG4vLyAgY29uc3QgYW1vdW50SW5DZW50cyA9IGFtb3VudCAqIDEwMDtcclxuLy8gIGNvbnN0IGRhdGUgPSBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc3BsaXQoJ1QnKVswXTtcclxuIFxyXG4vLyAgIGF3YWl0IHNxbGBcclxuLy8gICAgIElOU0VSVCBJTlRPIGludm9pY2VzIChjdXN0b21lcl9pZCwgYW1vdW50LCBzdGF0dXMsIGRhdGUpXHJcbi8vICAgICBWQUxVRVMgKCR7Y3VzdG9tZXJJZH0sICR7YW1vdW50SW5DZW50c30sICR7c3RhdHVzfSwgJHtkYXRlfSlcclxuLy8gICBgXHJcbi8vICAgICByZXZhbGlkYXRlUGF0aCgnL2Rhc2hib2FyZC9pbnZvaWNlcycpO1xyXG4vLyAgIHJlZGlyZWN0KCcvZGFzaGJvYXJkL2ludm9pY2VzJyk7XHJcbi8vICAgLy8gVGVzdCBpdCBvdXQ6XHJcbi8vIC8vICAgY29uc29sZS5sb2cocmF3Rm9ybURhdGEpO1xyXG4vLyB9XHJcblxyXG4vLyBjb25zdCBVcGRhdGVJbnZvaWNlID0gRm9ybVNjaGVtYS5vbWl0KHsgaWQ6IHRydWUsIGRhdGU6IHRydWUgfSk7XHJcblxyXG4vLyBleHBvcnQgYXN5bmMgZnVuY3Rpb24gdXBkYXRlSW52b2ljZShpZDogc3RyaW5nLCBmb3JtRGF0YTogRm9ybURhdGEpIHtcclxuLy8gICBjb25zdCB7IGN1c3RvbWVySWQsIGFtb3VudCwgc3RhdHVzIH0gPSBVcGRhdGVJbnZvaWNlLnBhcnNlKHtcclxuLy8gICAgIGN1c3RvbWVySWQ6IGZvcm1EYXRhLmdldCgnY3VzdG9tZXJJZCcpLFxyXG4vLyAgICAgYW1vdW50OiBmb3JtRGF0YS5nZXQoJ2Ftb3VudCcpLFxyXG4vLyAgICAgc3RhdHVzOiBmb3JtRGF0YS5nZXQoJ3N0YXR1cycpLFxyXG4vLyAgIH0pO1xyXG4gXHJcbi8vICAgY29uc3QgYW1vdW50SW5DZW50cyA9IGFtb3VudCAqIDEwMDtcclxuIFxyXG4vLyAgIGF3YWl0IHNxbGBcclxuLy8gICAgIFVQREFURSBpbnZvaWNlc1xyXG4vLyAgICAgU0VUIGN1c3RvbWVyX2lkID0gJHtjdXN0b21lcklkfSwgYW1vdW50ID0gJHthbW91bnRJbkNlbnRzfSwgc3RhdHVzID0gJHtzdGF0dXN9XHJcbi8vICAgICBXSEVSRSBpZCA9ICR7aWR9XHJcbi8vICAgYDtcclxuIFxyXG4vLyAgIHJldmFsaWRhdGVQYXRoKCcvZGFzaGJvYXJkL2ludm9pY2VzJyk7XHJcbi8vICAgcmVkaXJlY3QoJy9kYXNoYm9hcmQvaW52b2ljZXMnKTtcclxuLy8gfVxyXG5cclxuLy8gZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGRlbGV0ZUludm9pY2UoaWQ6IHN0cmluZykge1xyXG4vLyAgIGF3YWl0IHNxbGBERUxFVEUgRlJPTSBpbnZvaWNlcyBXSEVSRSBpZCA9ICR7aWR9YDtcclxuLy8gICByZXZhbGlkYXRlUGF0aCgnL2Rhc2hib2FyZC9pbnZvaWNlcycpO1xyXG4vLyB9XHJcblxyXG4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IndSQXFIc0IifQ==
}}),
"[project]/app/ui/login-form.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

{
__turbopack_context__.s({
    "default": (()=>LoginForm)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$0$2d$canary$2e$34_react_7c4e108657a2500366dd8081e08c8b03$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.0-canary.34_react_7c4e108657a2500366dd8081e08c8b03/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$0$2d$canary$2e$34_react_7c4e108657a2500366dd8081e08c8b03$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.0-canary.34_react_7c4e108657a2500366dd8081e08c8b03/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$0$2d$canary$2e$34_react_7c4e108657a2500366dd8081e08c8b03$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.0-canary.34_react_7c4e108657a2500366dd8081e08c8b03/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$data$3a$2b146f__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/lib/data:2b146f [app-ssr] (ecmascript) <text/javascript>");
(()=>{
    const e = new Error("Cannot find module '@/components/ui/button'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
(()=>{
    const e = new Error("Cannot find module '@/components/ui/input'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
(()=>{
    const e = new Error("Cannot find module '@/components/ui/label'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$11$2e$4_react_bb95b72af8e5be2906382556b9d23d68$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/framer-motion@12.11.4_react_bb95b72af8e5be2906382556b9d23d68/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-ssr] (ecmascript)");
(()=>{
    const e = new Error("Cannot find module 'lucide-react'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
'use client';
;
;
;
;
;
;
;
;
;
;
function LoginForm() {
    const searchParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$0$2d$canary$2e$34_react_7c4e108657a2500366dd8081e08c8b03$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useSearchParams"])();
    const callbackUrl = searchParams.get('callbackUrl') || '/dashboard';
    const [errorMessage, formAction, isPending] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$0$2d$canary$2e$34_react_7c4e108657a2500366dd8081e08c8b03$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useActionState"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$data$3a$2b146f__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["authenticate"], undefined);
    const [showPassword, setShowPassword] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$0$2d$canary$2e$34_react_7c4e108657a2500366dd8081e08c8b03$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$0$2d$canary$2e$34_react_7c4e108657a2500366dd8081e08c8b03$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "min-h-screen flex items-center justify-center bg-gray-100 dark:bg-gray-900 p-4",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$0$2d$canary$2e$34_react_7c4e108657a2500366dd8081e08c8b03$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$11$2e$4_react_bb95b72af8e5be2906382556b9d23d68$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["motion"].div, {
            initial: {
                opacity: 0,
                scale: 0.9
            },
            animate: {
                opacity: 1,
                scale: 1
            },
            transition: {
                duration: 0.5,
                ease: 'easeOut'
            },
            className: "w-full max-w-md bg-white dark:bg-gray-800 rounded-xl shadow-2xl p-8",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$0$2d$canary$2e$34_react_7c4e108657a2500366dd8081e08c8b03$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mb-6 text-center",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$0$2d$canary$2e$34_react_7c4e108657a2500366dd8081e08c8b03$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                            className: "text-2xl font-bold text-gray-900 dark:text-white",
                            children: "Iniciar Sesión"
                        }, void 0, false, {
                            fileName: "[project]/app/ui/login-form.tsx",
                            lineNumber: 28,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$0$2d$canary$2e$34_react_7c4e108657a2500366dd8081e08c8b03$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-gray-600 dark:text-gray-400 mt-1",
                            children: "Ingresa tus credenciales para continuar"
                        }, void 0, false, {
                            fileName: "[project]/app/ui/login-form.tsx",
                            lineNumber: 29,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/ui/login-form.tsx",
                    lineNumber: 27,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$0$2d$canary$2e$34_react_7c4e108657a2500366dd8081e08c8b03$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                    action: formAction,
                    className: "space-y-6",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$0$2d$canary$2e$34_react_7c4e108657a2500366dd8081e08c8b03$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$0$2d$canary$2e$34_react_7c4e108657a2500366dd8081e08c8b03$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(Label, {
                                    htmlFor: "email",
                                    className: "text-sm font-medium text-gray-700 dark:text-gray-300",
                                    children: "Email"
                                }, void 0, false, {
                                    fileName: "[project]/app/ui/login-form.tsx",
                                    lineNumber: 34,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$0$2d$canary$2e$34_react_7c4e108657a2500366dd8081e08c8b03$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "relative",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$0$2d$canary$2e$34_react_7c4e108657a2500366dd8081e08c8b03$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(AtSign, {
                                            className: "absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400 dark:text-gray-500"
                                        }, void 0, false, {
                                            fileName: "[project]/app/ui/login-form.tsx",
                                            lineNumber: 38,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$0$2d$canary$2e$34_react_7c4e108657a2500366dd8081e08c8b03$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(Input, {
                                            id: "email",
                                            name: "email",
                                            type: "email",
                                            placeholder: "Ingrese email",
                                            required: true,
                                            className: "pl-10 py-3 text-sm bg-gray-50 dark:bg-gray-700 border-gray-300 dark:border-gray-600 focus:border-indigo-500 focus:ring-indigo-500 rounded-lg"
                                        }, void 0, false, {
                                            fileName: "[project]/app/ui/login-form.tsx",
                                            lineNumber: 39,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/ui/login-form.tsx",
                                    lineNumber: 37,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/ui/login-form.tsx",
                            lineNumber: 33,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$0$2d$canary$2e$34_react_7c4e108657a2500366dd8081e08c8b03$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$0$2d$canary$2e$34_react_7c4e108657a2500366dd8081e08c8b03$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(Label, {
                                    htmlFor: "password",
                                    className: "text-sm font-medium text-gray-700 dark:text-gray-300",
                                    children: "Contraseña"
                                }, void 0, false, {
                                    fileName: "[project]/app/ui/login-form.tsx",
                                    lineNumber: 51,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$0$2d$canary$2e$34_react_7c4e108657a2500366dd8081e08c8b03$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "relative",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$0$2d$canary$2e$34_react_7c4e108657a2500366dd8081e08c8b03$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(Key, {
                                            className: "absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400 dark:text-gray-500"
                                        }, void 0, false, {
                                            fileName: "[project]/app/ui/login-form.tsx",
                                            lineNumber: 55,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$0$2d$canary$2e$34_react_7c4e108657a2500366dd8081e08c8b03$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(Input, {
                                            id: "password",
                                            name: "password",
                                            type: showPassword ? 'text' : 'password',
                                            placeholder: "Ingrese contraseña",
                                            required: true,
                                            className: "pl-10 py-3 text-sm bg-gray-50 dark:bg-gray-700 border-gray-300 dark:border-gray-600 focus:border-indigo-500 focus:ring-indigo-500 rounded-lg"
                                        }, void 0, false, {
                                            fileName: "[project]/app/ui/login-form.tsx",
                                            lineNumber: 56,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$0$2d$canary$2e$34_react_7c4e108657a2500366dd8081e08c8b03$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            type: "button",
                                            onClick: ()=>setShowPassword(!showPassword),
                                            className: "absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 dark:text-gray-500 hover:text-gray-600 dark:hover:text-gray-400",
                                            children: showPassword ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$0$2d$canary$2e$34_react_7c4e108657a2500366dd8081e08c8b03$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(EyeOff, {
                                                className: "h-5 w-5"
                                            }, void 0, false, {
                                                fileName: "[project]/app/ui/login-form.tsx",
                                                lineNumber: 69,
                                                columnNumber: 33
                                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$0$2d$canary$2e$34_react_7c4e108657a2500366dd8081e08c8b03$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(Eye, {
                                                className: "h-5 w-5"
                                            }, void 0, false, {
                                                fileName: "[project]/app/ui/login-form.tsx",
                                                lineNumber: 69,
                                                columnNumber: 66
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/app/ui/login-form.tsx",
                                            lineNumber: 64,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/ui/login-form.tsx",
                                    lineNumber: 54,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/ui/login-form.tsx",
                            lineNumber: 50,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$0$2d$canary$2e$34_react_7c4e108657a2500366dd8081e08c8b03$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                            type: "hidden",
                            name: "redirectTo",
                            value: callbackUrl
                        }, void 0, false, {
                            fileName: "[project]/app/ui/login-form.tsx",
                            lineNumber: 74,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$0$2d$canary$2e$34_react_7c4e108657a2500366dd8081e08c8b03$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(Button, {
                            type: "submit",
                            className: "w-full bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-3 rounded-lg text-sm shadow-md hover:shadow-lg transition-all duration-300",
                            disabled: isPending,
                            children: [
                                isPending ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$0$2d$canary$2e$34_react_7c4e108657a2500366dd8081e08c8b03$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$framer$2d$motion$40$12$2e$11$2e$4_react_bb95b72af8e5be2906382556b9d23d68$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["motion"].div, {
                                    animate: {
                                        rotate: 360
                                    },
                                    transition: {
                                        duration: 1,
                                        repeat: Infinity,
                                        ease: 'linear'
                                    },
                                    className: "w-5 h-5 border-2 border-white border-t-transparent rounded-full mr-2"
                                }, void 0, false, {
                                    fileName: "[project]/app/ui/login-form.tsx",
                                    lineNumber: 82,
                                    columnNumber: 15
                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$0$2d$canary$2e$34_react_7c4e108657a2500366dd8081e08c8b03$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(LogIn, {
                                    className: "mr-2 h-5 w-5"
                                }, void 0, false, {
                                    fileName: "[project]/app/ui/login-form.tsx",
                                    lineNumber: 88,
                                    columnNumber: 15
                                }, this),
                                isPending ? 'Ingresando...' : 'Iniciar Sesión'
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/ui/login-form.tsx",
                            lineNumber: 76,
                            columnNumber: 11
                        }, this),
                        errorMessage && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$0$2d$canary$2e$34_react_7c4e108657a2500366dd8081e08c8b03$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center space-x-2 text-red-500 text-sm",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$0$2d$canary$2e$34_react_7c4e108657a2500366dd8081e08c8b03$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                    xmlns: "http://www.w3.org/2000/svg",
                                    fill: "none",
                                    viewBox: "0 0 24 24",
                                    strokeWidth: 1.5,
                                    stroke: "currentColor",
                                    className: "w-5 h-5",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$0$2d$canary$2e$34_react_7c4e108657a2500366dd8081e08c8b03$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                        strokeLinecap: "round",
                                        strokeLinejoin: "round",
                                        d: "M12 9v2m0 4h.01m-6.938 4h13.856c1.054 0 1.918-.816 1.994-1.85L21 18.2c0-.819-.293-1.61-.828-2.239L13.41 9.48a2.25 2.25 0 00-3.315 0L3.828 15.96A3.163 3.163 0 003 18.2c0 1.034.832 1.8 1.857 1.8z"
                                    }, void 0, false, {
                                        fileName: "[project]/app/ui/login-form.tsx",
                                        lineNumber: 103,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/ui/login-form.tsx",
                                    lineNumber: 95,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$0$2d$canary$2e$34_react_7c4e108657a2500366dd8081e08c8b03$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    children: errorMessage
                                }, void 0, false, {
                                    fileName: "[project]/app/ui/login-form.tsx",
                                    lineNumber: 109,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/ui/login-form.tsx",
                            lineNumber: 94,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/ui/login-form.tsx",
                    lineNumber: 32,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/ui/login-form.tsx",
            lineNumber: 21,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/app/ui/login-form.tsx",
        lineNumber: 20,
        columnNumber: 5
    }, this);
}
}}),

};

//# sourceMappingURL=app_8b9fe7a9._.js.map