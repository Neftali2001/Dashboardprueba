(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_ac031c8b._.js",
  "static/chunks/app_ui_search_tsx_ca724a1b._.js"
],
    source: "dynamic"
});
