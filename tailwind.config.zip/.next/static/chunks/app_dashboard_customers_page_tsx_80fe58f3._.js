(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules__pnpm_d6f21555._.js",
  "static/chunks/[root-of-the-server]__c6395d02._.js"
],
    source: "dynamic"
});
