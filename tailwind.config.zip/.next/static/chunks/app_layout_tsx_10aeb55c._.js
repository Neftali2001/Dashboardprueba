(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__81e4402d._.css",
  "static/chunks/3222a_next_dist_5f7c7a3b._.js"
],
    source: "dynamic"
});
