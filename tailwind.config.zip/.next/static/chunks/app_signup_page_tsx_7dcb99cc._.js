(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/78375_tailwind-merge_dist_bundle-mjs_mjs_46ec1965._.js",
  "static/chunks/e056e_react-icons_fa_index_mjs_19ed1800._.js",
  "static/chunks/e056e_react-icons_lib_046ab61e._.js",
  "static/chunks/node_modules__pnpm_0de8107e._.js",
  "static/chunks/_ce8ed2e9._.js"
],
    source: "dynamic"
});
